var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__26879f06._.js")
R.c("server/chunks/80b94_Hashim_emirads__next-internal_server_app_favicon_ico_route_actions_53f79541.js")
R.m(25989)
module.exports=R.m(25989).exports
