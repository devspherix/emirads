1:"$Sreact.fragment"
2:I[46794,["/_next/static/chunks/389794678b6b8fcf.js","/_next/static/chunks/cab1fb6c72c4002a.js"],"default"]
3:I[67125,["/_next/static/chunks/389794678b6b8fcf.js","/_next/static/chunks/cab1fb6c72c4002a.js"],"default"]
0:{"buildId":"KgcY5ZUGo2SKy6nqinAXK","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
