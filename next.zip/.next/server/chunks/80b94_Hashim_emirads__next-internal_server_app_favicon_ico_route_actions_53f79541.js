module.exports=[13448,(e,o,d)=>{}];

//# sourceMappingURL=80b94_Hashim_emirads__next-internal_server_app_favicon_ico_route_actions_53f79541.js.map