module.exports=[16163,(a,b,c)=>{}];

//# sourceMappingURL=Documents_Hashim_emirads__next-internal_server_app_quote_page_actions_3efc398e.js.map