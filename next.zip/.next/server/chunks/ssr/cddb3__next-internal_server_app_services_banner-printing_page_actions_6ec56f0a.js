module.exports=[1788,(a,b,c)=>{}];

//# sourceMappingURL=cddb3__next-internal_server_app_services_banner-printing_page_actions_6ec56f0a.js.map