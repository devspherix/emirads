module.exports=[19153,(a,b,c)=>{}];

//# sourceMappingURL=Documents_Hashim_emirads__next-internal_server_app_about_page_actions_9f766663.js.map