module.exports=[13217,(a,b,c)=>{}];

//# sourceMappingURL=Documents_Hashim_emirads__next-internal_server_app_page_actions_74281e4c.js.map