module.exports=[62600,(a,b,c)=>{}];

//# sourceMappingURL=80b94_Hashim_emirads__next-internal_server_app__not-found_page_actions_480814f6.js.map