module.exports=[69439,(a,b,c)=>{}];

//# sourceMappingURL=Documents_Hashim_emirads__next-internal_server_app_terms_page_actions_5a917b82.js.map