module.exports=[57875,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},81484,a=>{"use strict";let b={src:a.i(57875).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=Documents_Hashim_emirads_src_app_2e40fde0._.js.map