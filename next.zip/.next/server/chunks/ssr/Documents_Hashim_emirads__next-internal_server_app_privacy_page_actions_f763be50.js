module.exports=[38136,(a,b,c)=>{}];

//# sourceMappingURL=Documents_Hashim_emirads__next-internal_server_app_privacy_page_actions_f763be50.js.map