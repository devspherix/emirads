module.exports=[5234,(a,b,c)=>{}];

//# sourceMappingURL=ba398_server_app_services_safety-compliance-signage_page_actions_d45694ab.js.map