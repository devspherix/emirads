module.exports=[75933,(a,b,c)=>{}];

//# sourceMappingURL=80b94_Hashim_emirads__next-internal_server_app_projects_page_actions_aa569c3b.js.map