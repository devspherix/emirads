module.exports=[56178,(a,b,c)=>{"use strict";b.exports=a.r(69348).vendored["react-ssr"].ReactDOM}];

//# sourceMappingURL=166e1_next_dist_server_route-modules_app-page_vendored_ssr_react-dom_b7928319.js.map