module.exports=[44983,(a,b,c)=>{}];

//# sourceMappingURL=80b94_Hashim_emirads__next-internal_server_app__global-error_page_actions_422b10c7.js.map