module.exports=[13248,(a,b,c)=>{}];

//# sourceMappingURL=Documents_Hashim_emirads__next-internal_server_app_faq_page_actions_b3cabf37.js.map