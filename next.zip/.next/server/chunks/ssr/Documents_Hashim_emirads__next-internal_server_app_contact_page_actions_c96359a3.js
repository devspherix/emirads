module.exports=[14970,(a,b,c)=>{}];

//# sourceMappingURL=Documents_Hashim_emirads__next-internal_server_app_contact_page_actions_c96359a3.js.map