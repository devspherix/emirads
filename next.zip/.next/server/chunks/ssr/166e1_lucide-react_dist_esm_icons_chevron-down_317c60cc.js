module.exports=[61044,a=>{"use strict";let b=(0,a.i(63077).default)("chevron-down",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);a.s(["ChevronDown",()=>b],61044)}];

//# sourceMappingURL=166e1_lucide-react_dist_esm_icons_chevron-down_317c60cc.js.map