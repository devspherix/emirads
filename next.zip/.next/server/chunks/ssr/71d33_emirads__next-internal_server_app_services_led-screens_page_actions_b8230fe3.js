module.exports=[27420,(a,b,c)=>{}];

//# sourceMappingURL=71d33_emirads__next-internal_server_app_services_led-screens_page_actions_b8230fe3.js.map