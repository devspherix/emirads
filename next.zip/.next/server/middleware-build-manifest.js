globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c4fb450c5a60c83b.js",
    "static/chunks/869dc25b96776fc9.js",
    "static/chunks/8b6af3e9c4dc494a.js",
    "static/chunks/fc6c9d6e055a0fdc.js",
    "static/chunks/turbopack-8f1f4163069e3b1d.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];